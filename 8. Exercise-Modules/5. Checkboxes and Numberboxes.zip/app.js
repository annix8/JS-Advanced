let Checkbox = require('./Checkbox.js');
let Numberbox = require('./Numberbox.js');

result.Checkbox = Checkbox;
result.Numberbox = Numberbox;