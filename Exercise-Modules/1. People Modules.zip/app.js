let Employee = require('./Employee.js');
let Junior = require('./Junior.js');
let Senior = require('./Senior.js');
let Manager = require('./Manager.js');


result.Employee= Employee;
result.Junior = Junior;
result.Senior = Senior;
result.Manager = Manager;