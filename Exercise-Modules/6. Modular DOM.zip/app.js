let BaseElement = require('./BaseElement.js');
let TitleBar = require('./TitleBar.js');
let Footer = require('./Footer.js');
let Article = require('./Article.js');
let ImageArticle = require('./ImageArticle.js');
let TableArticle = require('./TableArticle.js');

result.BaseElement = BaseElement;
result.TitleBar = TitleBar;
result.Footer = Footer;
result.Article = Article;
result.ImageArticle = ImageArticle;
result.TableArticle = TableArticle;