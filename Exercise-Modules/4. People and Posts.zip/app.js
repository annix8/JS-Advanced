let Person = require('./Person.js');
let Post = require('./Post.js');

result.Person = Person;
result.Post = Post;