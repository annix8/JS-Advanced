let Turtle = require('./Turtle.js');
let WaterTurtle = require('./WaterTurtle.js');
let GalapagosTurtle = require('./GalapagosTurtle.js');
let EvkodianTurtle = require('./EvkodianTurtle.js');
let NinjaTurtle = require('./NinjaTurtle.js')

result.Turtle = Turtle;
result.WaterTurtle = WaterTurtle;
result.GalapagosTurtle = GalapagosTurtle;
result.EvkodianTurtle = EvkodianTurtle;
result.NinjaTurtle = NinjaTurtle;

