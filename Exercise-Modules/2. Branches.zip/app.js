let Branch = require('./Branch')
let Employee = require('./Employee.js');



result.Employee= Employee;
result.Branch = Branch;
