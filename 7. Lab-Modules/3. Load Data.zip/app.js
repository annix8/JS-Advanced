let data = require('./example.js');

function sort(property) {
     let resultArr = data.sort((a,b)=>{
        if(a[property] < b[property]){
            return -1;
        }
        else if(a[property] > b[property]){
            return 1;
        }
        return 0;
    });

    return resultArr;
}

function filter(property, value) {
    let resultArr = data.filter(w => w[property] === value);
    return resultArr;

}

result.sort = sort;
result.filter = filter;
