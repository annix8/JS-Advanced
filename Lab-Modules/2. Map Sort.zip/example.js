function mapSort(map,func) {
    let resultMap = new Map();

    let allWords = Array.from(map.entries()).sort(func);
    for (let word of allWords){
        resultMap.set(word[0],word[1]);
    }

    return resultMap;
}

//let map = new Map();
//map.set(3,{age:13,hoby:"Skiing"});
//map.set(1,{name:"Stamat",age:29,color:"blue"});
//map.set(7,{name:"Yordan",age:3});
//console.log(mapSort(map, (a, b)=>a[1].age - b[1].age));
module.exports = mapSort;