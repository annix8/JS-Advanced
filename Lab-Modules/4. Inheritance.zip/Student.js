let Person = require('./Person.js');
let Dog = require('./Dog.js');

class Student extends Person{
    constructor(name,phrase,dog,id){
        super(name,phrase,dog);
        this.id = id;
    }

    saySomething(){
        return `Id: ${this.id} ${this.name} says: ${this.phrase}${this.dog.name} barks!`;
    }

}
let dog = new Dog('sparky');
let st = new Student('kridho', 'tapak',dog,25)
console.log(st.saySomething());
module.exports = Student;