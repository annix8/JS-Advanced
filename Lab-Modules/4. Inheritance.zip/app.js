let Entity = require('./Entity.js');
let Dog = require('./Dog.js');
let Person = require('./Person.js');
let Student = require('./Student.js');

result.Entity = Entity;
result.Person = Person;
result.Dog = Dog;
result.Student = Student;
